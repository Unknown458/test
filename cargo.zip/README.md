# Notes

1. Create ".env.production" file for production version with similar environment variables as in ".env.development".
