// -------------------------------------------------------------------------------------------

enum AppDetails {
	Title = 'CargoJet',
	Rights = 'All Rights Reserved. © 2024. Crystal Technosoft Pvt Ltd.',
	SupportPhone = '8055533151',
	SupportEmail = 'support@crystaltechnosoft.com',
}

// -------------------------------------------------------------------------------------------

export default AppDetails;

// -------------------------------------------------------------------------------------------
