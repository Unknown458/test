import './Quotations.scss';

import dayjs, { Dayjs } from 'dayjs';
import {
	MaterialReactTable,
	MRT_ColumnDef,
	useMaterialReactTable,
} from 'material-react-table';
import { memo, useCallback, useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

import { AddOutlined, DeleteOutline, EditOutlined } from '@mui/icons-material';
import { LoadingButton } from '@mui/lab';
import {
	Button,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle,
	Fab,
	FormControl,
	FormHelperText,
	IconButton,
	InputLabel,
	MenuItem,
	OutlinedInput,
	Select,
	Tooltip,
	useMediaQuery,
	useTheme,
} from '@mui/material';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';

import RouterPath from '../../../app/routerPath';
import ActiveToggle from '../../../components/ActiveToggle/ActiveToggle';
import Alert from '../../../components/Alert/Alert';
import {
	AlertInterface,
	AlertStates,
} from '../../../components/Alert/Alert.types';
import Fallback from '../../../components/Fallback/Fallback';
import { FallbackStateType } from '../../../components/Fallback/Fallback.types';
import Search from '../../../components/Search/Search';
import { useApi } from '../../../contexts/Api/Api';
import { useApp } from '../../../contexts/App/App';
import { useAuth } from '../../../contexts/Auth/Auth';
import { ArticleShapeInterface } from '../../../services/articleShape/articleShape.types';
import { BranchInterface } from '../../../services/branch/branch.types';
import { GoodsTypeInterface } from '../../../services/goodsType/goodsType.types';
import {
	createQuotationAsync,
	deleteQuotationAsync,
	getQuotationsByPartyAsync,
	updateQuotationAsync,
} from '../../../services/quotation/quotation';
import {
	QuotationInterface,
	RateTypeInterface,
} from '../../../services/quotation/quotation.types';
import addIndex from '../../../utils/addIndex';

// -------------------------------------------------------------------------------------------

const defaultFormData: QuotationInterface = {
	quotationDate: new Date().toISOString(),
	partyId: 0,
	branchId: 0,
	goodsTypeId: 0,
	shapeId: 0,
	rateType: 0,
	branchRate: 0,
	billRate: 0,
	hamaliType: 0,
	branchHamali: 0,
	billHamali: 0,
	branchCollectionCharges: 0,
	billCollectionCharges: 0,
	branchDoorDeliveryCharges: 0,
	billDoorDeliveryCharges: 0,
	deliverydays: 0,
	isActive: true,
};

const defaultFormErrors = {
	quotationDate: '',
	branchId: '',
	goodsTypeId: '',
	shapeId: '',
	rateType: '',
	branchRate: '',
	billRate: '',
	hamaliType: '',
	branchHamali: '',
	billHamali: '',
	deliverydays: '',
};

// -------------------------------------------------------------------------------------------

const Quotations = memo(() => {
	const { setTitle } = useApp();
	const { handleLogout } = useAuth();
	const {
		getGoodsTypes,
		getRateTypes,
		getAllActiveDeliveryBranches,
		getArticleShapes,
	} = useApi();
	const navigate = useNavigate();
	const location = useLocation();
	const [windowWidth, setWindowWidth] = useState(window.innerWidth);

	const [isFormDialogOpen, setIsFormDialogOpen] = useState(false);
	const [isFormDialogEditMode, setIsFormDialogEditMode] = useState(false);
	const [isFormDialogLoading, setIsFormDialogLoading] = useState(false);
	const [fallbackState, setFallbackState] =
		useState<FallbackStateType>('loading');
	const [quotations, _setQuotations] = useState<QuotationInterface[]>([]);
	const [rawQuotations, _setRawQuotations] = useState<QuotationInterface[]>(
		[]
	);
	const [goodsTypes, _setGoodsTypes] = useState<GoodsTypeInterface[]>([]);
	const [rateTypes, _setRateTypes] = useState<RateTypeInterface[]>([]);
	const [branches, _setBranches] = useState<BranchInterface[]>([]);
	const [articleShapes, _setArticleShapes] = useState<
		ArticleShapeInterface[]
	>([]);
	const [formData, setFormData] =
		useState<QuotationInterface>(defaultFormData);
	const [formErrors, setFormErrors] = useState(defaultFormErrors);
	const [alertDialog, setAlertDialog] = useState<AlertInterface>({
		state: 'success',
		label: '',
		isActive: false,
	});

	const theme = useTheme();
	const isDialogFullScreen = useMediaQuery(theme.breakpoints.down('sm'));

	useEffect(() => {
		setTitle('Quotations');
		initialFetch();
	}, [getGoodsTypes, getRateTypes, getAllActiveDeliveryBranches, setTitle]);

	useEffect(() => {
		const updateWindowWidth = () => setWindowWidth(window.innerWidth);
		window.addEventListener('resize', updateWindowWidth);
		return () => window.removeEventListener('resize', updateWindowWidth);
	}, []);

	const initialFetch = async () => {
		if (location.state) {
			const quotationsData = await getQuotationsByParty(
				location.state.party.partyId
			);
			const goodsTypesData = await getGoodsTypes();
			const rateTypesData = await getRateTypes();

			const articleShapesData = await getArticleShapes();

			if (branches.length === 0) {
				const allActiveDeliveryBranchesData =
					await getAllActiveDeliveryBranches();

				_setBranches(allActiveDeliveryBranchesData);
			}

			if (
				goodsTypesData.length !== 0 &&
				rateTypesData.length !== 0 &&
				articleShapesData.length !== 0
			) {
				_setQuotations(quotationsData);
				_setRawQuotations(quotationsData);
				_setGoodsTypes(goodsTypesData);
				_setRateTypes(rateTypesData);
				_setArticleShapes(articleShapesData);
				setFallbackState('hidden');
			} else {
				setFallbackState('not-found');
			}

			if (quotationsData.length !== 0) {
				setFallbackState('hidden');
			} else {
				setFallbackState('not-found');
			}
		} else {
			navigate(RouterPath.Dashboard, { replace: true });
		}
	};

	const getQuotationsByParty = useCallback(
		async (partyId: number): Promise<QuotationInterface[]> => {
			const response = await getQuotationsByPartyAsync(partyId);

			if (
				response &&
				typeof response !== 'boolean' &&
				response.data.status !== 401
			) {
				const data: any = response.data.data.reverse();

				return addIndex(data);
			} else {
				handleLogout();
				return [];
			}
		},
		[]
	);

	const handleOpenFormDialog = useCallback((data?: QuotationInterface) => {
		setIsFormDialogOpen(true);
		if (data) {
			setFormData(data);
			setIsFormDialogEditMode(true);
		}
	}, []);

	const handleCloseFormDialog = useCallback(() => {
		setIsFormDialogOpen(false);
		setFormData(defaultFormData);
		setFormErrors(defaultFormErrors);
		setIsFormDialogEditMode(false);
		setIsFormDialogLoading(false);
		handleCloseAlertDialog();
	}, []);

	const handleOpenAlertDialog = useCallback(
		(state: AlertStates, label: string) => {
			setAlertDialog({ state, label, isActive: true });
		},
		[]
	);

	const handleCloseAlertDialog = useCallback(() => {
		setAlertDialog({ state: 'success', label: '', isActive: false });
	}, []);

	const handleSearch = async (keyword: string) => {
		const array = rawQuotations;

		if (!keyword || keyword.trim() === '') {
			_setQuotations(array);
			return;
		}

		const regex = new RegExp(keyword.trim(), 'i');

		const filteredQuotations = array.filter(
			(quotation: QuotationInterface) => {
				const branchName = quotation.branchId
					? branches.find(
							(branch) => branch.branchId === quotation.branchId
					  )?.name || ''
					: '';
				const goodsTypeName = quotation.goodsTypeId
					? goodsTypes.find(
							(type) => type.goodsTypeId === quotation.goodsTypeId
					  )?.goodsType || ''
					: '';
				const rateTypeName = quotation.rateType
					? rateTypes.find(
							(type) => type.rateTypeId === quotation.rateType
					  )?.rateType || ''
					: '';
				const branchRate = quotation.branchRate?.toString() || '';
				const billRate = quotation.billRate?.toString() || '';
				const hamaliType = quotation.rateType
					? rateTypes.find(
							(type) => type.rateTypeId === quotation.hamaliType
					  )?.rateType || ''
					: '';
				const branchHamali = quotation.branchHamali?.toString() || '';
				const billHamali = quotation.billHamali?.toString() || '';
				const branchCollectionCharges =
					quotation.branchCollectionCharges?.toString() || '';
				const billCollectionCharges =
					quotation.billCollectionCharges?.toString() || '';
				const branchDoorDeliveryCharges =
					quotation.branchDoorDeliveryCharges?.toString() || '';
				const billDoorDeliveryCharges =
					quotation.billDoorDeliveryCharges?.toString() || '';
				const deliverydays = quotation.deliverydays?.toString() || '';

				return (
					regex.test(branchName) ||
					regex.test(goodsTypeName) ||
					regex.test(rateTypeName) ||
					regex.test(branchRate) ||
					regex.test(billRate) ||
					regex.test(hamaliType) ||
					regex.test(branchHamali) ||
					regex.test(billHamali) ||
					regex.test(branchCollectionCharges) ||
					regex.test(billCollectionCharges) ||
					regex.test(branchDoorDeliveryCharges) ||
					regex.test(billDoorDeliveryCharges) ||
					regex.test(deliverydays)
				);
			}
		);

		_setQuotations(addIndex(filteredQuotations));
	};

	const validateQuotation = useCallback((): boolean => {
		const errors = { ...defaultFormErrors };

		if (!formData?.quotationDate) {
			errors.quotationDate = 'Quotation Date is required.';
		}
		if (!formData?.branchId) {
			errors.branchId = 'Branch is required.';
		}
		if (!formData?.goodsTypeId) {
			errors.goodsTypeId = 'Goods Type is required.';
		}
		if (!formData?.shapeId) {
			errors.shapeId = 'Article Shape is required.';
		}
		if (!formData?.rateType) {
			errors.rateType = 'Rate Type is required.';
		}
		if (!formData?.branchRate) {
			errors.branchRate = 'Branch Rate is required.';
		}
		if (!formData?.billRate) {
			errors.billRate = 'Bill Rate is required.';
		}
		if (!formData?.hamaliType) {
			errors.hamaliType = 'Hamali Type is required.';
		}
		if (!formData?.branchHamali) {
			errors.branchHamali = 'Branch Hamali is required.';
		}
		if (!formData?.billHamali) {
			errors.billHamali = 'Bill Hamali is required.';
		}
		if (!formData?.deliverydays) {
			errors.deliverydays = 'Delivery Days is required.';
		}
		setFormErrors(errors);

		return Object.values(errors).every((error) => error === '');
	}, [formData]);

	const handleCreateQuotation = async () => {
		if (!validateQuotation()) return;

		const data = {
			quotationDate: formData.quotationDate
				? new Date(formData.quotationDate).toISOString()
				: new Date().toISOString(),
			partyId: location.state.party.partyId
				? location.state.party.partyId
				: 0,
			branchId: formData.branchId ? +formData.branchId : 0,
			goodsTypeId: formData.goodsTypeId ? +formData.goodsTypeId : 0,
			shapeId: formData.shapeId ? +formData.shapeId : 0,
			rateType: formData.rateType ? formData.rateType : null,
			branchRate: formData.branchRate ? +formData.branchRate : 0,
			billRate: formData.billRate ? +formData.billRate : 0,
			hamaliType: formData.hamaliType ? formData.hamaliType : null,
			branchHamali: formData.branchHamali ? +formData.branchHamali : 0,
			billHamali: formData.billHamali ? +formData.billHamali : 0,
			branchCollectionCharges: formData.branchCollectionCharges
				? +formData.branchCollectionCharges
				: 0,
			billCollectionCharges: formData.billCollectionCharges
				? +formData.billCollectionCharges
				: 0,
			branchDoorDeliveryCharges: formData.branchDoorDeliveryCharges
				? +formData.branchDoorDeliveryCharges
				: 0,
			billDoorDeliveryCharges: formData.billDoorDeliveryCharges
				? +formData.billDoorDeliveryCharges
				: 0,
			deliverydays: formData.deliverydays ? +formData.deliverydays : 0,
			isActive: formData.isActive,
		};

		setIsFormDialogLoading(true);
		try {
			const response = await createQuotationAsync(data);
			if (
				response &&
				typeof response !== 'boolean' &&
				response.data.status !== 401
			) {
				if (response.data.status === 200) {
					const newQuotation: QuotationInterface = {
						...formData,
						quotationId: response.data.data,
					};
					_setQuotations((prev) => addIndex([newQuotation, ...prev]));
					_setRawQuotations((prev) =>
						addIndex([newQuotation, ...prev])
					);
					handleCloseFormDialog();
					handleOpenAlertDialog('success', 'Created new Quotation.');
					setFallbackState('hidden');
				} else {
					handleOpenAlertDialog('warning', response.data.data);
				}
			} else {
				handleLogout();
			}
		} catch (error) {
			handleLogout();
		} finally {
			setIsFormDialogLoading(false);
		}
	};

	const handleUpdateQuotation = async () => {
		if (!validateQuotation()) return;

		const data = { ...formData };

		setIsFormDialogLoading(true);
		try {
			const response = await updateQuotationAsync(data);
			if (
				response &&
				typeof response !== 'boolean' &&
				response.data.status !== 401
			) {
				if (response.data.status === 200) {
					const updatedQuotations = quotations.map((obj) =>
						obj.quotationId === formData.quotationId ? data : obj
					);

					_setQuotations(addIndex(updatedQuotations));
					_setRawQuotations(addIndex(updatedQuotations));
					handleCloseFormDialog();
					handleOpenAlertDialog('success', 'Updated Quotation.');
				} else {
					handleOpenAlertDialog('warning', response.data.data);
				}
			} else {
				handleLogout();
			}
		} catch (error) {
			handleLogout();
		} finally {
			setIsFormDialogLoading(false);
		}
	};

	const handleDeleteQuotation = async (data: QuotationInterface) => {
		const confirm = window.confirm(
			`Are you sure you want to delete Quotation?`
		);
		if (!confirm) return;

		const quotationId = data.quotationId as number;

		try {
			const response = await deleteQuotationAsync(quotationId);
			if (
				response &&
				typeof response !== 'boolean' &&
				response.data.status !== 401
			) {
				if (response.data.status === 200) {
					const updatedQuotations = quotations.filter(
						(obj) => obj.quotationId !== quotationId
					);
					_setQuotations(addIndex(updatedQuotations));
					_setRawQuotations(addIndex(updatedQuotations));
					handleOpenAlertDialog('success', 'Deleted Quotation.');
					if (updatedQuotations.length === 0) {
						setFallbackState('not-found');
					}
				} else {
					handleOpenAlertDialog('warning', response.data.data);
				}
			} else {
				handleLogout();
			}
		} catch (error) {
			handleLogout();
		}
	};

	const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
	};

	const columns = useMemo<MRT_ColumnDef<QuotationInterface>[]>(
		() => [
			{
				accessorKey: 'index',
				header: '#',
				enableResizing: false,
				size: 80,
				muiTableHeadCellProps: { align: 'left' },
				muiTableBodyCellProps: { align: 'left' },
				muiTableFooterCellProps: { align: 'left' },
			},
			{
				accessorKey: 'branchId',
				header: 'Delivery Branch',
				enableResizing: true,
				size: 80,
				muiTableHeadCellProps: { align: 'left' },
				muiTableBodyCellProps: { align: 'left' },
				muiTableFooterCellProps: { align: 'left' },
				Cell: ({ cell }) => {
					const branchId = cell.getValue<number>();
					const branch = branches.find(
						(branch) => branch.branchId === branchId
					);
					return branch ? branch.name : '';
				},
			},
			{
				accessorKey: 'goodsTypeId',
				header: 'Goods Type',
				enableResizing: true,
				size: 80,
				muiTableHeadCellProps: { align: 'left' },
				muiTableBodyCellProps: { align: 'left' },
				muiTableFooterCellProps: { align: 'left' },
				Cell: ({ cell }) => {
					const goodsTypeId = cell.getValue<number>();
					const goodsType = goodsTypes.find(
						(type) => type.goodsTypeId === goodsTypeId
					);
					return goodsType ? goodsType.goodsType : '';
				},
			},
			{
				accessorKey: 'actions',
				header: 'Actions',
				enableResizing: false,
				enableColumnFilter: false,
				enableSorting: false,
				size: 100,
				muiTableHeadCellProps: { align: 'right' },
				muiTableBodyCellProps: { align: 'right' },
				muiTableFooterCellProps: { align: 'right' },
				Cell: ({ row }) => (
					<>
						<Tooltip title='Delete Quotation'>
							<IconButton
								onClick={() =>
									handleDeleteQuotation(row.original)
								}
							>
								<DeleteOutline />
							</IconButton>
						</Tooltip>
						<Tooltip title='Edit Quotation'>
							<IconButton
								onClick={() =>
									handleOpenFormDialog(row.original)
								}
							>
								<EditOutlined />
							</IconButton>
						</Tooltip>
					</>
				),
			},
		],
		[
			handleDeleteQuotation,
			handleOpenFormDialog,
			branches,
			goodsTypes,
			_setQuotations,
			_setRawQuotations,
			quotations,
			rawQuotations,
		]
	);

	const table = useMaterialReactTable({
		columns,
		data: quotations,
		filterFromLeafRows: true,
		paginateExpandedRows: false,
		enableColumnResizing: true,
		enablePagination: true,
		layoutMode: 'grid',
		enableDensityToggle: false,
		initialState: {
			pagination: { pageSize: 100, pageIndex: 0 },
			density: 'compact',
		},
		muiPaginationProps: { rowsPerPageOptions: [100, 200, 500, 1000] },
		muiTablePaperProps: {
			sx: {
				borderRadius: 'var(--shape-medium)',
				boxShadow: 'var(--elevation-extra-small)',
			},
		},
		muiTableBodyCellProps: { sx: { paddingTop: 0, paddingBottom: 0 } },
	});

	return (
		<>
			<div
				data-component='quotations'
				className='container'
			>
				<div
					data-component='quotations'
					className='top'
				>
					<Search
						onChange={handleSearch}
						isDisabled={fallbackState !== 'hidden'}
					/>
					{windowWidth > 600 && (
						<Tooltip title='Create New Quotation'>
							<Fab
								variant='extended'
								color='primary'
								data-component='quotations'
								className='fab'
								onClick={() => handleOpenFormDialog()}
							>
								<AddOutlined />
								Create new
							</Fab>
						</Tooltip>
					)}
				</div>
				<div
					data-component='quotations'
					className='bottom'
				>
					{fallbackState !== 'hidden' ? (
						<Fallback state={fallbackState} />
					) : (
						<>
							<div
								data-component='quotations'
								className='party-name title-medium'
							>
								Party Name:{' '}
								{location.state.party.partyName
									? location.state.party.partyName
									: '--'}
							</div>
							<div
								data-component='quotations'
								className='table-container'
							>
								<MaterialReactTable table={table} />
							</div>
						</>
					)}
				</div>
			</div>

			{windowWidth < 600 && (
				<div
					data-component='agents'
					className='fab-container'
				>
					<Tooltip title='Create New Quotation'>
						<Fab
							variant='extended'
							color='primary'
							data-component='quotations'
							className='fab'
							onClick={() => handleOpenFormDialog()}
						>
							<AddOutlined />
							Create new
						</Fab>
					</Tooltip>
				</div>
			)}

			<Dialog
				open={isFormDialogOpen}
				onClose={handleCloseFormDialog}
				fullWidth={true}
				maxWidth='md'
				fullScreen={isDialogFullScreen}
				data-component='quotations'
				className='dialog'
			>
				<DialogTitle
					data-component='quotations'
					className='dialog-title'
				>
					{!isFormDialogEditMode
						? 'Create New Quotation'
						: 'Edit Quotation'}
					<ActiveToggle
						isActive={formData.isActive}
						onChange={(value) => {
							setFormData((prev) => ({
								...prev,
								isActive: value,
							}));
						}}
					/>
				</DialogTitle>
				<DialogContent
					data-component='quotations'
					className='dialog-content'
				>
					<div
						data-component='quotations'
						className='container'
					>
						<div
							data-component='quotations'
							className='columns-2'
						>
							<FormControl
								size='medium'
								disabled={isFormDialogLoading}
								variant='outlined'
								fullWidth
								error={formErrors.branchId ? true : false}
							>
								<InputLabel>Delivery Branch</InputLabel>
								<Select
									label='Delivery Branch'
									value={
										formData?.branchId
											? formData?.branchId
											: ''
									}
									name='branchId'
									onChange={(e) => {
										setFormData((prev) => ({
											...prev,
											branchId: e.target.value as number,
										}));
									}}
								>
									{branches.map((branch) => {
										return (
											<MenuItem
												key={`branch-${branch.branchId}`}
												value={
													branch.branchId as number
												}
											>
												{branch.name}
											</MenuItem>
										);
									})}
								</Select>
								{formErrors.branchId && (
									<FormHelperText error>
										{formErrors.branchId}
									</FormHelperText>
								)}
							</FormControl>
							<FormControl
								size='medium'
								disabled={isFormDialogLoading}
								variant='outlined'
								fullWidth
								error={formErrors.goodsTypeId ? true : false}
							>
								<InputLabel>Goods Type</InputLabel>
								<Select
									label='Goods Type'
									value={
										formData?.goodsTypeId
											? formData?.goodsTypeId
											: ''
									}
									name='goodsTypeId'
									onChange={(e) => {
										setFormData((prev) => ({
											...prev,
											goodsTypeId: e.target
												.value as number,
										}));
									}}
								>
									{goodsTypes.map((type) => {
										return (
											<MenuItem
												key={`goods-type-${type.goodsTypeId}`}
												value={type.goodsTypeId}
											>
												{type.goodsType}
											</MenuItem>
										);
									})}
								</Select>
								{formErrors.goodsTypeId && (
									<FormHelperText error>
										{formErrors.goodsTypeId}
									</FormHelperText>
								)}
							</FormControl>
							<FormControl
								size='medium'
								disabled={isFormDialogLoading}
								variant='outlined'
								fullWidth
								error={formErrors.shapeId ? true : false}
							>
								<InputLabel>Article Shape</InputLabel>
								<Select
									label='Article Shape'
									value={
										formData?.shapeId
											? formData?.shapeId
											: ''
									}
									name='shapeId'
									onChange={(e) => {
										setFormData((prev) => ({
											...prev,
											shapeId: e.target.value as number,
										}));
									}}
								>
									{articleShapes.map((shape) => {
										return (
											<MenuItem
												key={`article-shape-${shape.articleShapeId}`}
												value={shape.articleShapeId}
											>
												{shape.articleShape}
											</MenuItem>
										);
									})}
								</Select>
								{formErrors.shapeId && (
									<FormHelperText error>
										{formErrors.shapeId}
									</FormHelperText>
								)}
							</FormControl>
							<FormControl
								size='medium'
								disabled={isFormDialogLoading}
								variant='outlined'
								fullWidth
								error={formErrors.quotationDate ? true : false}
							>
								<LocalizationProvider
									dateAdapter={AdapterDayjs}
								>
									<DatePicker
										label='Date'
										format='DD-MM-YYYY'
										value={
											formData.quotationDate
												? dayjs(formData.quotationDate)
												: null
										}
										disabled={isFormDialogLoading}
										onChange={(date: Dayjs | null) => {
											if (date) {
												setFormData((prev) => ({
													...prev,
													quotationDate:
														date.toISOString(),
												}));
											} else {
												setFormData((prev) => ({
													...prev,
													quotationDate: '',
												}));
											}
										}}
										slotProps={{
											field: {
												shouldRespectLeadingZeros: true,
											},
											popper: {
												placement: 'auto',
											},
										}}
									/>
								</LocalizationProvider>
								{formErrors.quotationDate && (
									<FormHelperText error>
										{formErrors.quotationDate}
									</FormHelperText>
								)}
							</FormControl>
							<FormControl
								size='medium'
								disabled={isFormDialogLoading}
								variant='outlined'
								fullWidth
								error={formErrors.deliverydays ? true : false}
							>
								<InputLabel htmlFor='delivery-days'>
									Delivery Days
								</InputLabel>
								<OutlinedInput
									label='Delivery Days'
									id='delivery-days'
									type='number'
									value={
										formData?.deliverydays
											? formData?.deliverydays
											: ''
									}
									name='deliverydays'
									onChange={handleChange}
								/>
								{formErrors.deliverydays && (
									<FormHelperText error>
										{formErrors.deliverydays}
									</FormHelperText>
								)}
							</FormControl>
						</div>
						<div
							data-component='quotations'
							className='columns-2'
						>
							<div
								data-component='quotations'
								className='container'
							>
								<div
									data-component='quotations'
									className='columns-3'
								>
									<FormControl
										size='medium'
										disabled={isFormDialogLoading}
										variant='outlined'
										fullWidth
										error={
											formErrors.rateType ? true : false
										}
									>
										<InputLabel>Rate Type</InputLabel>
										<Select
											label='Rate Type'
											value={
												formData?.rateType
													? formData?.rateType
													: ''
											}
											name='rateType'
											onChange={(e) => {
												setFormData((prev) => ({
													...prev,
													rateType: e.target
														.value as number,
												}));
											}}
										>
											{rateTypes.map((type) => {
												return (
													<MenuItem
														key={type.rateTypeId}
														value={type.rateTypeId}
													>
														{type.rateType}
													</MenuItem>
												);
											})}
										</Select>
										{formErrors.rateType && (
											<FormHelperText error>
												{formErrors.rateType}
											</FormHelperText>
										)}
									</FormControl>
								</div>
								<div
									data-component='quotations'
									className='columns-3'
								>
									<FormControl
										size='medium'
										disabled={isFormDialogLoading}
										variant='outlined'
										fullWidth
										error={
											formErrors.branchRate ? true : false
										}
									>
										<InputLabel htmlFor='branch-rate'>
											Branch Rate
										</InputLabel>
										<OutlinedInput
											label='Branch Rate'
											id='branch-rate'
											type='number'
											value={
												formData?.branchRate
													? formData?.branchRate
													: ''
											}
											name='branchRate'
											onChange={handleChange}
										/>
										{formErrors.branchRate && (
											<FormHelperText error>
												{formErrors.branchRate}
											</FormHelperText>
										)}
									</FormControl>
								</div>
								<div
									data-component='quotations'
									className='columns-3'
								>
									<FormControl
										size='medium'
										disabled={isFormDialogLoading}
										variant='outlined'
										fullWidth
										error={
											formErrors.billRate ? true : false
										}
									>
										<InputLabel htmlFor='bill-rate'>
											Bill Rate
										</InputLabel>
										<OutlinedInput
											label='Bill Rate'
											id='bill-rate'
											type='number'
											value={
												formData?.billRate
													? formData?.billRate
													: ''
											}
											name='billRate'
											onChange={handleChange}
										/>
										{formErrors.billRate && (
											<FormHelperText error>
												{formErrors.billRate}
											</FormHelperText>
										)}
									</FormControl>
								</div>
							</div>
							<div
								data-component='quotations'
								className='container'
							>
								<div
									data-component='quotations'
									className='columns-3'
								>
									<FormControl
										size='medium'
										disabled={isFormDialogLoading}
										variant='outlined'
										fullWidth
										error={
											formErrors.hamaliType ? true : false
										}
									>
										<InputLabel>Hamali Type</InputLabel>
										<Select
											label='Hamali Type'
											value={
												formData?.hamaliType
													? formData?.hamaliType
													: ''
											}
											name='hamaliType'
											onChange={(e) => {
												setFormData((prev) => ({
													...prev,
													hamaliType: e.target
														.value as number,
												}));
											}}
										>
											{rateTypes.map((type) => {
												return (
													<MenuItem
														key={type.rateTypeId}
														value={type.rateTypeId}
													>
														{type.rateType}
													</MenuItem>
												);
											})}
										</Select>
										{formErrors.hamaliType && (
											<FormHelperText error>
												{formErrors.hamaliType}
											</FormHelperText>
										)}
									</FormControl>
								</div>
								<div
									data-component='quotations'
									className='columns-3'
								>
									<FormControl
										size='medium'
										disabled={isFormDialogLoading}
										variant='outlined'
										fullWidth
										error={
											formErrors.branchHamali
												? true
												: false
										}
									>
										<InputLabel htmlFor='branch-hamali-rate'>
											Branch Hamali Rate
										</InputLabel>
										<OutlinedInput
											label='Branch Hamali Rate'
											id='branch-hamali-rate'
											type='number'
											value={
												formData?.branchHamali
													? formData?.branchHamali
													: ''
											}
											name='branchHamali'
											onChange={handleChange}
										/>
										{formErrors.branchHamali && (
											<FormHelperText error>
												{formErrors.branchHamali}
											</FormHelperText>
										)}
									</FormControl>
								</div>
								<div
									data-component='quotations'
									className='columns-3'
								>
									<FormControl
										size='medium'
										disabled={isFormDialogLoading}
										variant='outlined'
										fullWidth
										error={
											formErrors.billHamali ? true : false
										}
									>
										<InputLabel htmlFor='hamali-bill-rate'>
											Hamali Bill Rate
										</InputLabel>
										<OutlinedInput
											label='Hamali Bill Rate'
											id='hamali-bill-rate'
											type='number'
											value={
												formData?.billHamali
													? formData?.billHamali
													: ''
											}
											name='billHamali'
											onChange={handleChange}
										/>
										{formErrors.billHamali && (
											<FormHelperText error>
												{formErrors.billHamali}
											</FormHelperText>
										)}
									</FormControl>
								</div>
							</div>
							<div
								data-component='quotations'
								className='container'
							>
								<div
									data-component='quotations'
									className='columns-2'
								>
									<FormControl
										size='medium'
										disabled={isFormDialogLoading}
										variant='outlined'
										fullWidth
									>
										<InputLabel htmlFor='branch-collection-charges'>
											Branch Collection Charges
										</InputLabel>
										<OutlinedInput
											label='Branch Collection Charges'
											id='branch-collection-charges'
											type='number'
											value={
												formData?.branchCollectionCharges
													? formData?.branchCollectionCharges
													: ''
											}
											name='branchCollectionCharges'
											onChange={handleChange}
										/>
									</FormControl>
								</div>
								<div
									data-component='quotations'
									className='columns-2'
								>
									<FormControl
										size='medium'
										disabled={isFormDialogLoading}
										variant='outlined'
										fullWidth
									>
										<InputLabel htmlFor='bill-collection-charges'>
											Bill Collection Charges
										</InputLabel>
										<OutlinedInput
											label='Bill Collection Charges'
											id='bill-collection-charges'
											type='number'
											value={
												formData?.billCollectionCharges
													? formData?.billCollectionCharges
													: ''
											}
											name='billCollectionCharges'
											onChange={handleChange}
										/>
									</FormControl>
								</div>
							</div>
							<div
								data-component='quotations'
								className='container'
							>
								<div
									data-component='quotations'
									className='columns-2'
								>
									<FormControl
										size='medium'
										disabled={isFormDialogLoading}
										variant='outlined'
										fullWidth
									>
										<InputLabel htmlFor='branch-door-delivery-charges'>
											Branch Door Delivery Charges
										</InputLabel>
										<OutlinedInput
											label='Branch Door Delivery Charges'
											id='branch-door-delivery-charges'
											type='number'
											value={
												formData?.branchDoorDeliveryCharges
													? formData?.branchDoorDeliveryCharges
													: ''
											}
											name='branchDoorDeliveryCharges'
											onChange={handleChange}
										/>
									</FormControl>
								</div>
								<div
									data-component='quotations'
									className='columns-2'
								>
									<FormControl
										size='medium'
										disabled={isFormDialogLoading}
										variant='outlined'
										fullWidth
									>
										<InputLabel htmlFor='bill-door-delivery-charges'>
											Bill Door Delivery Charges
										</InputLabel>
										<OutlinedInput
											label='Bill Door Delivery Charges'
											id='bill-door-delivery-charges'
											type='number'
											value={
												formData?.billDoorDeliveryCharges
													? formData?.billDoorDeliveryCharges
													: ''
											}
											name='billDoorDeliveryCharges'
											onChange={handleChange}
										/>
									</FormControl>
								</div>
							</div>
						</div>
					</div>
				</DialogContent>
				<DialogActions>
					<Button onClick={handleCloseFormDialog}>Close</Button>
					<LoadingButton
						color='primary'
						onClick={
							!isFormDialogEditMode
								? handleCreateQuotation
								: handleUpdateQuotation
						}
						loading={isFormDialogLoading}
						type='submit'
					>
						Save
					</LoadingButton>
				</DialogActions>
			</Dialog>

			<Alert
				{...alertDialog}
				onClose={handleCloseAlertDialog}
			/>
		</>
	);
});

// -------------------------------------------------------------------------------------------

export default Quotations;

// -------------------------------------------------------------------------------------------
