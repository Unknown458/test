// -------------------------------------------------------------------------------------------

export interface ArticleShapeInterface {
	articleShapeId?: number;
	articleShape: string;
	companyId?: number;
}

// -------------------------------------------------------------------------------------------
