// -------------------------------------------------------------------------------------------

export interface QuotationInterface {
	quotationId?: number;
	quotationDate: string;
	partyId: number;
	branchId: number;
	goodsTypeId: number;
	shapeId: number;
	rateType: number;
	branchRate: number;
	billRate: number;
	hamaliType: number;
	branchHamali: number;
	billHamali: number;
	branchCollectionCharges: number;
	billCollectionCharges: number;
	branchDoorDeliveryCharges: number;
	billDoorDeliveryCharges: number;
	deliverydays: number;
	isActive: boolean;
	addedBy?: number;
}

export interface RateTypeInterface {
	rateTypeId: number;
	rateType: string;
}

export interface CompanyQuotationInterface {
	companyQuotationId?: number;
	fromId: number;
	toId: number;
	goodsTypeId: number;
	shapeId: number;
	rateType: string;
	rate: number;
	companyId: number;
	userId: number;
}

// -------------------------------------------------------------------------------------------
